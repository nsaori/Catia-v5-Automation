﻿//20161102 txt를 읽어오고 점 찍기

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using MECMOD;
using HybridShapeTypeLib;   //GSMInterface
using System.IO;

namespace WireframeSurface
{
    class Point_fileIo
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("point.txt");
            String line = "";
            while ((line = sr.ReadLine()) != null)
            {
                
            }




            INFITF.Application catia;
            try
            {
                catia = (INFITF.Application)Marshal.GetActiveObject("CATIA.Application");
            }
            catch (Exception)
            {
                catia = (INFITF.Application)Activator.CreateInstance(Type.GetTypeFromProgID("CATIA.Application"));
            }
            catia.Visible = true;

            PartDocument prtdoc = (PartDocument)catia.Documents.Add("Part");
            Part prt = prtdoc.Part;

            HybridBodies hbdys = prt.HybridBodies;
            HybridBody hbdy = hbdys.Add();
            HybridShapeFactory hsFac = (HybridShapeFactory)prt.HybridShapeFactory;

            Point p1 = hsFac.AddNewPointCoord(10, 60, 30);
            Point p2 = hsFac.AddNewPointCoord(70, 75, 35);
            Point p3 = hsFac.AddNewPointCoord(100, 80, 30);
            Point p4 = hsFac.AddNewPointCoord(100, 80, 40);
            Point p5 = hsFac.AddNewPointCoord(95, 20, 45);
            Point p6 = hsFac.AddNewPointCoord(100, 10, 50);

            prt.Update();
        }
    }
}
